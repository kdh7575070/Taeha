from django.apps import AppConfig


class ContestConfig(AppConfig):
    name = 'contest'
